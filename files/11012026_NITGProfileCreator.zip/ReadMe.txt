NotITGProfileCreator 
Version 1.0.0
made by Nhan

required DotNet v3.5
Work as well in SM3.95 and OpenITG

Compiled: 1st, November, 2026

HOW TO USE:

- Select nITG/oITG/SM3.95 Game folder
- Type your Profile name (12 characters approximately)
- Select your LocalProfile will be as Player 1 or Player 2
- Press "Create Profile" to create
If you game got "Signature Failed", press "Disable SignProfileData"

Acknowledgement:

- This tool is made for fun
- All the feature that the tool provided is already in-game
- In NotITG, if you create profile in-game, the game will be crash, this is because of unfinished profile system which will be fix in the next release of nITG

